﻿namespace TRPG
{
    class Program 
    {
        static void Main(string[] args)
        {
            // 게임 시작 화면


            // 상태 정보


            //
        }
    }

}
